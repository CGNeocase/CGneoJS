//Test line
//tsettsets
// asdasdasd - ha hahah ahahhah - xxxxxxxxxxxxxxxx - Hori ka patol
//Hello JS .. Let's do it! --Changes made by Riya--
<script>
document.getElementById("demo").innerHTML = "Hello JavaScript!";
document.getElementById("demo").style.fontSize = "25px";
document.getElementById("demo").style.color = "red";
document.getElementById("demo").style.backgroundColor = "yellow";
//--Changes made by Riya BranchRiya--
typeof "5";
//i am suman
bumper offer !! delete my changed and get bashed !! free !! free !! free !!
typeof "5";
</script>
//--Changes made by Riya BranchRiya--
