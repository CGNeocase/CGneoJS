//my first JS
// modified in Pappu branch
//my first JS2
//my first JS3
//my changes in Fattu